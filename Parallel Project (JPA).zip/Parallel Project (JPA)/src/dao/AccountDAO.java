package dao;

import java.sql.*;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import bean.*;



public class AccountDAO 
{
	
	private EntityManager entityManager;
	
	public AccountDAO() 
	{
		entityManager = Util.getEntityManager();
	}
	
	/* *************Create Account **********************   */
	public void storeAccountsDetails(long ac,Account account1)
	{
		entityManager.persist(account1);
		
	
	}
	
	/* **************  Show Balance *************************    */
	public double showBal(long ac)
	{
		
		Account account = entityManager.find(Account.class, ac);
		System.out.println(account);
		return account.getBalance();
		
		
	}
	
	/* ************** Amount Transfer *************************       */ 
	public void transferAmount(long ac1, long ac2,double amount)
	{
		AccountDAO acdao=new AccountDAO();
		
		Account account1 = entityManager.find(Account.class, ac1);	
		Account account2 = entityManager.find(Account.class, ac2);
		double balance1 = account1.getBalance();
		double balance2 =account2.getBalance();
		
		acdao.beginTransaction();
		
		account1.setBalance(balance1-amount);
		account2.setBalance(balance2+amount);
		

		acdao.commitTransaction();
		System.out.println("Amount Transfered Successfully");
		
			
	}
		
		
	/* **************Deposite Balance ************************   */	
	public void setDepositedBal(long ac1,double amount)
	{
		AccountDAO acdao=new AccountDAO();
		acdao.beginTransaction();
		Account account = acdao.getAccount(ac1);
		account.setBalance(account.getBalance() + amount);
		acdao.commitTransaction();
		System.out.println("Amount Deposited Successfully");
		
	}
	
	/* ********************** Withdraw Amount *************************          */
	public void setWithdrawBal(long acc,double amount )
	{
		
		AccountDAO acdao=new AccountDAO();
		acdao.beginTransaction();
		Account account = acdao.getAccount(acc);
		account.setBalance(account.getBalance() - amount);
		acdao.commitTransaction();
		System.out.println("Amount has been withdrawn");
		
		
	}
	
	
	public void beginTransaction() {
		entityManager.getTransaction().begin();
	}
	
	public void commitTransaction() {
		entityManager.getTransaction().commit();
	}
	
	public Account getAccount(long accountNo) {
		Account account = entityManager.find(Account.class, accountNo);
	//System.out.println(account); 
		return account;
	}
	
	
	
}
