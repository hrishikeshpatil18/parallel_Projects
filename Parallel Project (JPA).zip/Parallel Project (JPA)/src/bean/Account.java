package bean;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account_JPA")
public class Account 
{
	@Id
	  
	//long accountNo=1800500L;
	long accountNo;
	  //String bankName="HDFC";
	 // String ifsc="Hdfc190065";
	double balance=0.0;
	
	@Embedded
	Customer customer;
	public Account()
	{
		
	}
	
	public Account(long accountNo,Customer cus) {			//remove increament from constructor .. line no 12 declare in ui and increment the acc no at the start of createAccount method call
		super();
		this.accountNo=accountNo;
		//Account(accountNo,/*bankName,ifsc,*/balance,cus);
		Account(accountNo,balance,cus);
		//i++;
	}
	
	public void Account(long accountNo,/* String bankName, String ifsc,*/ double balance, Customer customer) 
	{
		this.accountNo = accountNo;
		//this.bankName=bankName;
		//this.ifsc=ifsc;
		this.balance = balance;
		this.customer = customer;
		
	}
	
	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", balance=" + balance + ", customer=" + customer + "]";
	}
	
}
