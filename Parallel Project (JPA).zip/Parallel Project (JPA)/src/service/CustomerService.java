package service;




import bean.*;
import dao.*;

public class CustomerService 
{
	AccountDAO acdao=new AccountDAO();
	
	Account account=new Account();
	double bal;
	
	/* ****************************Create Account ************************************   */

	public void createAccount(long ac, Account a) 
	{
		
		acdao.beginTransaction();
		acdao.storeAccountsDetails(ac,a);
		acdao.commitTransaction();
	}
	
	/* *************************** Amount Transfer **************************************       */ 

	public void transferAmount(long ac1, long ac2, double amount)
	{
		
		acdao.transferAmount(ac1,ac2,amount);
	}
	
	/* *****************************Deposite Balance *************************************   */	

	public void depositeAmount(long ac1,double amount)
	{
		
		acdao.setDepositedBal(ac1,amount);
		
		
		/*acdao.beginTransaction();
		Account account = acdao.getAccount(ac1);
		account.setBalance(account.getBalance() + amount);
		acdao.commitTransaction();
		System.out.println("Amount Deposited Successfully");*/
		
	}
	
	/* *****************************Withdraw Balance **************************************   */	

	public void withdrawAmount(long acno,double amount1)
	{
		
		acdao.setWithdrawBal(acno,amount1);
		
		/*acdao.beginTransaction();
		Account account = acdao.getAccount(acno);
		account.setBalance(account.getBalance() - amount1);
		acdao.commitTransaction();
		System.out.println("Amount has been withdrawn");*/
		
	}
	
	
	public void storeTransactionDetails(long acno,Transaction t)
	{
		//tdao.storeTransactionDetailsDAO(acno, t);
	}
	
	/*public HashMap<Long,List<Transaction>> getTransactionDetails(long acno)
	{
		//HashMap <Long,List<Transaction>>hash=tdao. getTransactionDetailsDAO(acno);
		//return hash;
	}*/

	/* ****************************  Show Balance *************************************    */

	public double showBalance(long ac) 
	{
		// TODO Auto-generated method stub
		
		acdao.beginTransaction();
		double balance1= acdao.showBal(ac);
		acdao.commitTransaction();
		return balance1;
	}

}
