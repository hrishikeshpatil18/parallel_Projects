package dao;

import java.sql.*;
import java.sql.PreparedStatement;
import java.util.HashMap;
import bean.*;
import util.JdbcImpl;


public class AccountDAO 
{
	
	//static HashMap <Long,Account>hash=new HashMap<Long,Account>();
	Connection con = null;
	
	/* *************Create Account **********************   */
	public void storeAccountsDetails(long ac,Account account1)
	{
		
		try
		{
		
			con = JdbcImpl.getConnection1();
			String sql="INSERT INTO Bank_customer values(?,?,?,?,?,?)";
			PreparedStatement stmt = con.prepareStatement(sql);
			
			stmt.setDouble(1, account1.getAccountNo());
			stmt.setString(2, account1.getCustomer().getCustname());
			stmt.setString(3, account1.getCustomer().getCustaddress());
			stmt.setLong(4, account1.getCustomer().getCustphnNo());
			stmt.setString(5, account1.getCustomer().getCustmail());
			stmt.setDouble(6, account1.getBalance());
			
			stmt.executeUpdate();

			System.out.println("Account created successfully");
			
		}
		catch(SQLException e){System.out.println(e);}
		finally
		{
				if(con!=null)
				{
						try
						{
							con.close();
						}
						catch(SQLException e){System.out.println(e);}
				}
		}
	
	}
	
	/* **************  Show Balance *************************    */
	public double showBal(long ac)
	{
		//Connection conn = null;
		double value=0;
		try
		{
			
				con = JdbcImpl.getConnection1();
				String trans="";
				String sql = "select * from Bank_customer where accno=" + ac;
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next())
				{
					value=rs.getDouble(6);
				}
			
				//System.out.println("Shown...");
				return value;
			
		}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally 
			{
				if (con != null)
				{
					try 
					{
						con.close();
					} 
					catch (SQLException e) 
					{
						e.printStackTrace();
					}
				}
			}
		return value;
		
		
	}
	
	/* ************** Amount Transfer *************************       */ 
	public void transferAmount(long ac1, long ac2,double amount)
	{
		
		//Connection conn = null;
		double balance1=0,balance2=0;
		String trans="";
		try
		{
		
			con = JdbcImpl.getConnection1();
			
			String sql = "select * from Bank_customer where accno=" + ac1; 			//to retrieve acc balance of account1
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next())
			{
				balance1=rs.getDouble(6);
			}
		
			String sqls = "select * from Bank_customer where accno=" + ac2;			//to retrieve acc balance of account2
			Statement stmts = con.createStatement();
			ResultSet rss = stmts.executeQuery(sqls);
			while(rss.next())
			{
				balance2=rss.getDouble(6);
			}
			
		
			if(balance1>amount)				//to check whether original balance is sufficient or not to transfer the amount
			{
				
				String sql1 = "Update Bank_customer SET balance=? where accno=" + ac2;		//adding transfered amount to account2
				PreparedStatement stmt1 = con.prepareStatement(sql1);
				
				String msg="\nDeposit Amount : "+amount;
				double updatedBalance1= balance2 +amount;
				//trans=trans+" "+msg;
				stmt1.setDouble(1,updatedBalance1);
				//stmt1.setString(2, trans);
				
				stmt1.executeUpdate();
				
				String sql2 = "Update Bank_customer SET balance=? where accno=" + ac1;		//deducting transfered amount from account1
				PreparedStatement stmt2 = con.prepareStatement(sql2);
				//String msg1="\nDeposit Amount : "+amount;
				double updatedBalance2= balance1 - amount;
				trans=trans+" "+msg;
				stmt2.setDouble(1,updatedBalance2);
				//stmt1.setString(2, trans);
				
				stmt2.executeUpdate();
				System.out.println("Amount Successfully transfered...");
				
			}
			else
				System.out.println("You dont have sufficient balance to transfer amount");
			
		}
		catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally 
			{
				if (con != null)
				{
					try 
					{
						con.close();
					} 
					catch (SQLException e) 
					{
						e.printStackTrace();
					}
				}
			}
	}
		
		
	/* **************Deposite Balance ************************   */	
	public void setDepositedBal(long acc,double amount)
	{
		
		//Connection conn = null;
		double balance=0;
		try{
			
			
			con = JdbcImpl.getConnection1();
			String trans="";
			String sql = "select * from Bank_customer where accno=" + acc;
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery(sql);
			while(rs.next()){
			balance=rs.getDouble(6);
			//trans=rs.getString(7);
			}
			
			
			String sql2 = "Update Bank_customer SET balance=? where accno=" + acc;
			PreparedStatement stmt1 = con.prepareStatement(sql2);
			String msg="\nDeposit Amount : "+amount;
			double updatedBalance= balance +amount;
			trans=trans+" "+msg;
			stmt1.setDouble(1,updatedBalance);
			//stmt1.setString(2, trans);
			
			stmt1.executeUpdate();
		
			System.out.println("Amount Successfully Deposited");
			//System.out.println(getDetails(ac_no));
			//return getDetails(ac_no);
			
		}catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}
	
	/* ********************** Withdraw Amount *************************          */
	public void setWithdrawBal(long acc,double amount )
	{
		
		
		//Connection conn = null;
		try{
			
				double balance=0;
				con = JdbcImpl.getConnection1();
				String trans="";
				String sql = "select * from Bank_customer where accno=" + acc;
				Statement stmt = con.createStatement();
				ResultSet rs = stmt.executeQuery(sql);
				while(rs.next()){
				balance=rs.getDouble(6);
		
			}
			
			
			String sql2 = "Update Bank_customer SET balance=? where accno=" + acc;
			PreparedStatement stmt1 = con.prepareStatement(sql2);
			String msg="\nWithdrawn Amount : "+amount;
			
			if(amount>balance)										//check whether original balance is sufficient or not to withdraw 
			{
				System.out.println("No sufficient balance");
			}
			else
			{
				double updatedBalance= balance - amount;
				trans=trans+" "+msg;
				stmt1.setDouble(1,updatedBalance);
				//stmt1.setString(2, trans);
				
				stmt1.executeUpdate();
			
				System.out.println("Amount Successfully Withdrawn");
			}
			//System.out.println(getDetails(ac_no));
			//return getDetails(ac_no);
			
		}
		catch (SQLException e) 
		{
			e.printStackTrace();
		} 
		finally 
		{
			if (con != null) 
			{
				try 
				{
					con.close();
				} catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		
		
	}
	
	
	
}
