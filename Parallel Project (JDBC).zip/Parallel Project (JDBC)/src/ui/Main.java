package ui;
import service.*;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import service.*;
import bean.*;

public class Main
{

	static Account account;
	static Transaction transaction;
	static CustomerService cservice;
	
	public static void main(String args[])
	{
		CustomerService cs=new CustomerService();
		Scanner sc=new Scanner(System.in);
		int ch;
		boolean	check;
		String s="";
		do{
			
			System.out.println("[1] Create Acount");
			System.out.println("[2] Show Balance");
			System.out.println("[3] Deposite Amount");
			System.out.println("[4] Withdraw amount");
			System.out.println("[5] Transfer Amount");
			System.out.println("[6] Print Transaction");
			System.out.println("Enter your choice");
			
			ch=sc.nextInt();
			
			switch(ch)
			{
				case 1:				//Create Account
					System.out.println("Enter the customer name: ");
					String cname=sc.next();
					System.out.println("Enter the customer address: ");
					String address=sc.next();
					System.out.println("Enter the customer contact number: ");
					long phn=sc.nextLong();
					
					String phone=String.valueOf(phn);
					if(phone.length()!=10) 
					{
						System.out.println("Mobile number must be 10 digit long");
						break;
					}
						
					else
					{
						
						System.out.println("Enter the customer mail id: ");
						String mail=sc.next();
							
						Customer cus=new Customer(cname, address, phn, mail);
						account=new Account(cus);
						cservice=new CustomerService();
						cservice.createAccount(account.getAccountNo(), account);
					}
					
					
					break;
					
				case 2:			//show balance
					System.out.println("Enter your account no:");
					long ac=sc.nextLong();
					
					
					check=cservice.checkAccount(ac);  			//check whether account already exist or not
					if(check)                            				 //if account exist
					{
					
						double balance=cs.showBalance(ac);
						System.out.println("Account no: "+ac);
						System.out.println("Balance: "+balance);
					
					}
					else
					{
						System.out.println("Account Does not Exist");
					}
				
					break;
					
				case 3:				//deposite amount
					System.out.println("Enter your account no:");
					long ac1=sc.nextLong();
					
					
					check=cservice.checkAccount(ac1);  			//check whether account already exist or not
					if(check)                            				 //if account exist
					{
					
						System.out.println("Enter the amount u want to deposite");
						double amount=sc.nextDouble();
						cs.depositeAmount(ac1,amount);
						transaction=new Transaction("Deposite: ",amount);
						cs.storeTransactionDetails(ac1, transaction);
						
					
					}
					else
					{
						System.out.println("Account Does not Exist");
					}
					
					/*System.out.println("Enter the amount u want to deposite");
					double amount=sc.nextDouble();
					cs.depositeAmount(ac1,amount);
					transaction=new Transaction("Deposite: ",amount);
					cs.storeTransactionDetails(ac1, transaction);*/
					break;
					
				case 4:					//Withdraw amount
					System.out.println("Enter your account number");
					long ac2=sc.nextLong();
					
					check=cservice.checkAccount(ac2);  			//check whether account already exist or not
					if(check)                            				 //if account exist
					{
					
						System.out.println("Enter the amount u want to withdraw");
						double amountwith=sc.nextDouble();
						cs.withdrawAmount(ac2,amountwith);
						transaction=new Transaction("Withdraw: ",amountwith);
						cs.storeTransactionDetails(ac2, transaction);
					
					}
					else
					{
						System.out.println("Account Does not Exist");
					}
				/*	
					System.out.println("Enter the amount u want to withdraw");
					double amountwith=sc.nextDouble();
					cs.withdrawAmount(ac2,amountwith);
					transaction=new Transaction("Withdraw: ",amountwith);
					cs.storeTransactionDetails(ac2, transaction);*/
					break;
					
				case 5: 					//trnasfer amount
					System.out.println("Enter your account number");
					long ac3=sc.nextLong();
					
					check=cservice.checkAccount(ac3);  	
					if(check)                            				 //if account exist
					{}
					else
					{
						System.out.println("Account Does not Exist");
						break;
					}
					
					
					
					
					System.out.println("Enter the amount u want to transfer");
					double amountr1=sc.nextDouble();
					System.out.println("Enter account number to transfer amount");
					long ac4=sc.nextLong();
					
					
					check=cservice.checkAccount(ac4);  	
					if(check)                            				 //if account exist
					{}
					else
					{
						System.out.println("Account Does not Exist");
						break;
					}
					/*
					 cs.transfer(ac3,amountr1,ac4);
					 
					 */
					 cs.transferAmount(ac3,ac4,amountr1);
					 break;
					
				case 6:
					System.out.println("Enter your account number");
					long acnt=sc.nextLong();
					 HashMap<Long,List<Transaction>> hash= cs.getTransactionDetails(acnt);
					System.out.println(hash);
					break;
				default:	
					System.out.println("Invalid choice");
			}
			
			System.out.println("Do you want to continue..??");
			s=sc.next();
		}while(s.equals("y")||s.equals("Y"));
		
	sc.close();	
	}
	

}
