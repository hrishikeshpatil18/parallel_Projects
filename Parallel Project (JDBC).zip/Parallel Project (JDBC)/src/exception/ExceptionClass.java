package exception;

public class ExceptionClass extends Exception {
	

	public ExceptionClass(){
		super();
	}
	
	public ExceptionClass(String msg)
	{
		super(msg);
	}

}
