package service;

import java.util.HashMap;
import java.util.List;
import bean.*;
import dao.*;

public class CustomerService 
{
	AccountDAO acdao=new AccountDAO();
	TransactionDAO tdao=new TransactionDAO();
	Account account=new Account();
	double bal;
	
	/* ****************************Create Account ************************************   */

	public void createAccount(long ac, Account a) 
	{
		// TODO Auto-generated method stub
		acdao.storeAccountsDetails(ac,a);
	}
	
	/* *************************** Amount Transfer **************************************       */ 

	public void transferAmount(long ac1, long ac2, double amount)
	{
		
		acdao.transferAmount(ac1,ac2,amount);
	}
	
	/* *****************************Deposite Balance *************************************   */	

	public void depositeAmount(long ac1,double amount)
	{
		
		acdao.setDepositedBal(ac1,amount);
	}
	
	/* *****************************Withdraw Balance **************************************   */	

	public void withdrawAmount(long acno,double amount1)
	{
		
		acdao.setWithdrawBal(acno,amount1);
		
	}
	
	
	public void storeTransactionDetails(long acno,Transaction t)
	{
		tdao.storeTransactionDetailsDAO(acno, t);
	}
	
	public HashMap<Long,List<Transaction>> getTransactionDetails(long acno)
	{
		HashMap <Long,List<Transaction>>hash=tdao. getTransactionDetailsDAO(acno);
		return hash;
	}

	/* ****************************  Show Balance *************************************    */

	public double showBalance(long ac) 
	{
		// TODO Auto-generated method stub
		double balance1= acdao.showBal(ac);
		return balance1;
	}

}
