package bean;

public class Transaction {
    
    int transactionNo=100;
    String transactionType;
    double transactionAmount;
    static int count=0;
    
    public Transaction(int transactionNo, String transactionType, double transactionAmount) {
        super();
        this.transactionNo = transactionNo;
        this.transactionType = transactionType;
        this.transactionAmount = transactionAmount;
        count++;
    }

    public Transaction( String transactionType, double transactionAmount) {
        super();
        this.transactionNo = transactionNo + count;
        this.transactionType = transactionType;
        this.transactionAmount = transactionAmount;
        count++;
    }

    Transaction(){
        
    }

    public int getTransactionNo() {
        return transactionNo;
    }

    public void setTransactionNo(int transactionNo) {
        this.transactionNo = transactionNo;
    }

    public String getTransactionType() {
        return transactionType;
    }


    public void setTransactionType(String transactionType) {
        this.transactionType = transactionType;
    }

    public double getTransactionAmount() {
        return transactionAmount;
    }
    public void setTransactionAmount(double transactionAmount) {
        this.transactionAmount = transactionAmount;
    }


    @Override
    public String toString() {
        return "Transaction [transactionNo=" + transactionNo + ", transactionType=" + transactionType
                + ", transactionAmount=" + transactionAmount + "]";
    }   
}