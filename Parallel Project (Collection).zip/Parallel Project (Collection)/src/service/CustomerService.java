package service;

import java.util.HashMap;
import java.util.List;
import bean.*;
import dao.*;

public class CustomerService 
{
	AccountDAO acdao=new AccountDAO();
	TransactionDAO tdao=new TransactionDAO();
	Account account=new Account();
	double bal;
	
	public void createAccount(long ac, Account a) {
		// TODO Auto-generated method stub
		acdao.storeAccountsDetails(ac,a);
	}
	
	public Account getAccountService(long ac)
	{
		Account a2= acdao.showBal(ac);
		return a2;
	}
	

	public void depositeAmount(long ac1,double amount)
	{
		Account a3=acdao.updateBalance(ac1/*,account*/);
		double newBal=0;
		newBal=amount+a3.getBalance();
		a3.setBalance(newBal);
		acdao.setDepositedBal(ac1,a3);
	}
	
	public void withdrawAmount(long acno,double amount1)
	{
		
		Account a4=acdao.withdrawBalance(acno/*,account*/);
		if(amount1>a4.getBalance())
			System.out.println("No sufficient amount available in your account to withdraw.....");
		else
		{
			double newBal=0;
			newBal=a4.getBalance()-amount1;
			a4.setBalance(newBal);
			acdao.setWithdrawBal(acno,a4);
		}
		
	}
	
	public void transfer(long ac1,double amt1,long ac2)
	{
		Account a1=acdao.showBal(ac1);
		Account a2=acdao.showBal(ac2);
	}
	
	public void storeTransactionDetails(long acno,Transaction t)
	{
		tdao.storeTransactionDetailsDAO(acno, t);
	}
	
	public HashMap<Long,List<Transaction>> getTransactionDetails(long acno)
	{
		HashMap <Long,List<Transaction>>hash=tdao. getTransactionDetailsDAO(acno);
		return hash;
	}
	
	public boolean checkAccount(long ac) {
		
		return acdao.checkAccount(ac);
	}

	
	/*public void displayTrans(long acc) 
	{
		acdao.printTrans(acc);
	}*/

	
}
