package service;

public interface Service {
	public void depositeAmount(double amount);
	public void withdrawAmount();
	
	

}
