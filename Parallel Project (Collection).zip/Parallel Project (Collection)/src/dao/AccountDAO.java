package dao;

import java.util.HashMap;
import java.util.Set;
import bean.*;


public class AccountDAO 
{
	static HashMap <Long,Account>hash=new HashMap<Long,Account>();
	//static HashMap <Long,List>hash1=new HashMap<Long,List>();
	//List <Account>list=new ArrayList  <Account>();
	public void storeAccountsDetails(long ac,Account account1)
	{
		hash.put(ac, account1);
		System.out.println("Account created Successfully...!!");
		System.out.println(hash);
		
	}
	public Account showBal(long ac)
	{
		Set<Long>s=hash.keySet();
		for(long lo:s)
		{
			if(lo==ac)
			{
				return hash.get(lo);
			}
		}
		return null;
		
	}
	
	public Account updateBalance(long ac1/*,Account acobj*/)
	{
		Set<Long>s1=hash.keySet();
		for(long l:s1)
		{
			if(l==ac1)
			{
				return hash.get(l);
			}
			
		}
		return null;
	}
	public void setDepositedBal(long acc,Account acobj)
	{
		Set<Long>set=hash.keySet();
		for(long l:set)
		{
			if(l==acc)
			{
				hash.put(acc, acobj);
			//	list.add(acobj);
				System.out.println("Your account has been credited");
				
			}
			
		}
	}
	
	public Account withdrawBalance(long ac1/*,Account acobj*/)
	{
		Set<Long>s1=hash.keySet();
		for(long l:s1)
		{
			if(l==ac1)
			{
				return hash.get(l);
			}
		}
		return null;
	}
	
	public void setWithdrawBal(long acc,Account acobj)
	{
		Set<Long>set=hash.keySet();
		for(long l:set)
		{
			if(l==acc)
			{
				hash.put(acc, acobj);
				//list.add(acobj);
				System.out.println("Your account has been withrawn");
				
			}
			
		}
	}
	/*public void printTrans(long acc)
	{
		Set <Long> set=hash1.keySet();
		Iterator iterator=set.iterator();
		while(iterator.hasNext())
		{
			
		}
		
		/*Iterator iterator=list.iterator();
		while(iterator.hasNext())
		{
			Account acnt=(Account) iterator.next();
			long acno=acnt.getAccountNo();
			if(acc==acno)
				//System.out.println(acnt);
			//System.out.println(iterator.next());
		}*/
	
	
	
}
