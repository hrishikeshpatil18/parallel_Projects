package dao;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Set;

import bean.*;

public class TransactionDAO 
{
	List <Transaction> list=new ArrayList <Transaction>();
	HashMap<Long,List<Transaction>> thash= new HashMap<Long,List<Transaction>>();
	
	public void storeTransactionDetailsDAO(long acno, Transaction t)
	{
		list.add(t);
		thash.put(acno, list);
	}
	
	public HashMap<Long,List<Transaction>> getTransactionDetailsDAO(long acno)
	{
		Set<Long> set = thash.keySet();
	    boolean flag= false;
	    for(Long j: set) {
	        if(acno==j) {
	            flag=true;
	            break;
	            
	        }
	        else {
	            continue;
	        }
	    }
	    if(flag==true)
	    {
	        return thash;
	    }
	    else {
	            return null;
	    }
	    
	}
		
}

