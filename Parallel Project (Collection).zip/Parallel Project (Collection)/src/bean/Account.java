package bean;

public class Account 
{
	static int i=0;
	long accountNo=1800500L;
	
	double balance=0.0;
	Customer customer;
	public Account()
	{
		
	}
	
	public Account(Customer cus) {
		super();
		this.accountNo=accountNo+i;
		Account(accountNo,balance,cus);
		i++;
	}
	
	public void Account(long accountNo, double balance, Customer customer) 
	{
		this.accountNo = accountNo;
		this.balance = balance;
		this.customer = customer;
		
	}
	
	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", balance=" + balance + ", customer=" + customer + "]";
	}
	
}
