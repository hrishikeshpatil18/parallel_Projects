package ui;
import service.*;

import java.util.HashMap;
import java.util.List;
import java.util.Scanner;
import service.*;
import bean.*;

public class Main
{

	static Account account;
	static Transaction transaction;
	public static void main(String args[])
	{
		CustomerService cs=new CustomerService();
		Scanner sc=new Scanner(System.in);
		int ch;
		String s="";
		do{
			
			System.out.println("[1] Create Acount");
			System.out.println("[2] Show Balance");
			System.out.println("[3] Deposite Amount");
			System.out.println("[4] Withdraw amount");
			System.out.println("[5] Transfer Amount");
			System.out.println("[6] Print Transaction");
			System.out.println("Enter your choice");
			
			ch=sc.nextInt();
			switch(ch)
			{
				case 1:				//Create Account
					System.out.println("Enter the customer name: ");
					String cname=sc.next();
					System.out.println("Enter the customer address: ");
					String address=sc.next();
					System.out.println("Enter the customer contact number: ");
					long phn=sc.nextLong();
					System.out.println("Enter the customer mail id: ");
					String mail=sc.next();
					Customer cus=new Customer(cname, address, phn, mail);
					account=new Account(cus);
					CustomerService cservice=new CustomerService();
					cservice.createAccount(account.getAccountNo(), account);
				//	transaction=new Transaction();
					break;
					
				case 2:			//show balance
					System.out.println("Enter your account no:");
					long ac=sc.nextLong();
					Account a1=cs.getAccountService(ac);
					System.out.println("Account no: "+a1.getAccountNo());
					System.out.println("Balance: "+a1.getBalance());
					//System.out.println(a1);
					break;
					
				case 3:				//deposite amount
					System.out.println("Enter your account no:");
					long ac1=sc.nextLong();
					System.out.println("Enter the amount u want to deposite");
					double amount=sc.nextDouble();
					cs.depositeAmount(ac1,amount);
					transaction=new Transaction("Deposite: ",amount);
					cs.storeTransactionDetails(ac1, transaction);
					break;
					
				case 4:					//Withdraw amount
					System.out.println("Enter your account number");
					long ac2=sc.nextLong();
					System.out.println("Enter the amount u want to withdraw");
					double amountwith=sc.nextDouble();
					cs.withdrawAmount(ac2,amountwith);
					transaction=new Transaction("Withdraw: ",amountwith);
					cs.storeTransactionDetails(ac2, transaction);
					break;
					
				case 5: 					//trnasfer amount
					System.out.println("Enter your account number");
					long ac3=sc.nextLong();
					System.out.println("Enter the amount u want to transfer");
					double amountr1=sc.nextDouble();
					System.out.println("Enter account number to transfer amount");
					long ac4=sc.nextLong();
					/*
					 cs.transfer(ac3,amountr1,ac4);
					 
					 */
					
					
					Account aobj1=cs.getAccountService(ac3);
					Account aobj2=cs.getAccountService(ac4);
					if(aobj1.getBalance()<amountr1)
						System.out.println("You dont have sufficient balance to transfer");
					else
					{
						double newBalance1=aobj1.getBalance()-amountr1;
						aobj1.setBalance(newBalance1);
						
						double newBalance2=aobj2.getBalance()+amountr1;
						aobj2.setBalance(newBalance2);
						
						aobj1=cs.getAccountService(ac3);
						System.out.println("Account number: "+aobj1.getAccountNo() +"\n"+ "Account Balance: "+aobj1.getBalance());
						aobj2=cs.getAccountService(ac4);
						System.out.println("Account number: "+aobj2.getAccountNo() +"\n"+ "Account Balance: "+aobj2.getBalance());
					}
					
				case 6:
					System.out.println("Enter your account number");
					long acnt=sc.nextLong();
					 HashMap<Long,List<Transaction>> hash= cs.getTransactionDetails(acnt);
					System.out.println(hash);
					break;
				default:	
					System.out.println("Invalid choice");
			}
			
			System.out.println("Do you want to continue..??");
			s=sc.next();
		}while(s.equals("y")||s.equals("Y"));
	sc.close();	
	}
	

}
